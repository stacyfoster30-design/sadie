# HoldOff Social Media Poster Subagent
**Purpose:** Post the current content rotation to TikTok, X/Twitter, Instagram, LinkedIn  
**Frequency:** 4x daily (9am, 12pm, 3pm, 6pm MT)  
**Trigger:** Scheduled via cron (see SOCIAL_AUTOMATION_SETUP.md)

---

## Workflow

### Step 1: Load Current Rotation
Read `/tasklet/agent/home/social_post_rotation.json` to determine:
- TikTok script index (which of 5 scripts to post)
- X/Twitter thread index (which of 4 threads to post)
- Instagram content index
- LinkedIn enabled status

### Step 2: Get Content to Post

**From TikTok Scripts** (`/tasklet/agent/home/holdoff_tiktok_launch_scripts.md`):
- Pull the script at `tiktok[currentScriptIndex]`
- Create a 15-30 second video concept or use existing video asset

**From Twitter Threads** (`/tasklet/agent/home/x_twitter_midnight_launch.md`):
- Pull the thread at `twitter[currentThreadIndex]`
- Format as Twitter thread (if multi-tweet) or single tweet

**From Social Calendar** (`/tasklet/agent/home/HOLDOFF_SOCIAL_MEDIA_CALENDAR.md`):
- If using calendar-based posts, pull the post for today's day + current time slot (9am/12pm/3pm/6pm)

### Step 3: Post to Platforms

#### TikTok (@holdoffapp)
1. Log in to TikTok account (holdoff.3minpause@gmail.com)
2. Create new video post
3. Add caption from script
4. Add hashtags: #HoldOff #MentalHealthApp #RelationshipAnxiety #RSD #AnxietyRelief #TextAnxiety
5. Schedule or post immediately
6. Confirm post success

#### X/Twitter (@holdoffapp)
1. Log in to Twitter account
2. Post thread (if multi-part) or single tweet
3. Add link to shouldiholdoff.live or shouldiholdoff.live/app
4. Confirm post success

#### Instagram (@holdoffapp)
1. Log in to Instagram account
2. Create carousel or single image post
3. Add caption + hashtags
4. Confirm post success

#### LinkedIn
1. Log in to company page (if enabled)
2. Post professional version of content
3. Add #mentalwellness #corporatementalhealth
4. Confirm post success

### Step 4: Update Rotation Tracker
After successful posting:
```json
{
  "lastUpdated": "CURRENT_TIMESTAMP",
  "promoActive": true,
  "tiktok": {
    "currentScriptIndex": (nextIndex)
  },
  "twitter": {
    "currentThreadIndex": (nextIndex)
  },
  "instagram": {
    "currentIndex": (nextIndex)
  },
  "linkedin": {
    "enabled": false
  }
}
```

### Step 5: Log and Report
1. Record timestamp of post
2. Save post URLs/IDs for engagement tracking
3. Report success/failure back to Stacy

---

## Error Handling

**If login fails:**
- Log the error
- Notify Stacy via email
- Do not continue posting
- Trigger alert for credential refresh

**If platform is down:**
- Retry after 5 minutes
- Log retry attempt
- Continue with next platform

**If content is missing:**
- Fall back to social calendar content for today + time slot
- If that's also missing, notify Stacy

---

## Success Criteria

✅ Post successfully created on each platform  
✅ Rotation tracker updated  
✅ No errors in logs  
✅ Posts visible on accounts within 2 minutes of posting

---

## Notes

- This subagent relies on browser automation to log in and post
- Accounts: holdoff.3minpause@gmail.com
- Content rotates so the feed feels fresh and varied
- Timing is strict: posts must go out at exact scheduled times (9am, 12pm, 3pm, 6pm MT)

**Monitor:** Check @holdoffapp accounts 5 minutes after each scheduled time to confirm posts appeared
