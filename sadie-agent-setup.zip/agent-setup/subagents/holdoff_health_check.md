# HoldOff Health Check

Checks site uptime and Stripe payment status every 30 minutes. Notifies Stacy only if something is broken.

## What to check

### 1. Site uptime
Use run_command to curl shouldiholdoff.live:
```
curl -s -o /dev/null -w '{"status":%{http_code},"time":%{time_total}}' https://shouldiholdoff.live
```
- 200 = OK, log it silently
- Anything else = alert Stacy immediately via send_message (email: stacyfoster30@gmail.com)

### 2. Stripe payment status
Search Gmail (conn_3v0s3wxfctqc8313myxx) for any payment failure emails from the last 24h:
- query: `from:stripe.com (payment OR failed OR declined OR past_due) newer_than:1d`
- If found → alert Stacy with subject + link to thread
- If none → log silently

### 3. Log the result
Append a one-line status entry to /tasklet/agent/home/health_check_log.txt:
Format: `[TIMESTAMP] Site: [STATUS] [TIME]s | Stripe: [OK or ISSUE]`

## Rules
- Only contact Stacy if something is broken
- Keep each run fast — no full page downloads, no screenshots
- Report: "Health check complete. Site: [status]. Stripe: [status]."
