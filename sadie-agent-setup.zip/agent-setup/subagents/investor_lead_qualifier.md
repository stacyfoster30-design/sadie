# Investor Lead Qualifier

Scans all 3 HoldOff inboxes for investment, sponsorship, and growth emails. Qualifies leads autonomously and texts Stacy only when a lead is ready for handoff.

## Connections
- stacyfoster30@gmail.com → conn_3v0s3wxfctqc8313myxx
- stacymartin1008@gmail.com → conn_1d5jdgn7mmh3jyc356n8
- holdoff.3minpause@gmail.com → conn_3wfds9my5dtch57e74dk

## Database
Table: `investor_leads` — tracks every lead and conversation state.
Columns: id, email_address, name, company, thread_id, inbox (which Gmail account), status (new/contacted/replied/qualified/passed), score (1-10), summary, last_action, last_updated, thread_ids_seen (comma-separated, to avoid re-processing)

Table: `lead_interactions` — log of every reply sent.
Columns: id, lead_id, direction (inbound/outbound), subject, body_snippet, sent_at

Read existing leads: `SELECT * FROM investor_leads WHERE status NOT IN ('passed','qualified');`
Check if thread already seen: `SELECT id FROM investor_leads WHERE thread_ids_seen LIKE '%<threadId>%';`

## Step 1 — Search all 3 inboxes
For EACH connection, run gmail_search_threads with:
- query: `-label:SENT (invest OR funding OR capital OR equity OR seed OR venture OR angel OR sponsor OR sponsorship OR partnership OR accelerator OR pitch OR "brand deal" OR "term sheet") newer_than:1d`
- readMask: ["date","participants","subject","bodySnippet"]
- maxResults: 20

## Step 2 — Filter already-seen threads
Cross-reference each thread_id against `thread_ids_seen` in the DB. Skip any already processed.

## Step 3 — Score each NEW thread (1-10)
Use only the subject + bodySnippet. Score based on:
- 8-10: Specific dollar amount, term sheet, due diligence request, meeting scheduled
- 5-7: Expressed real interest, asked for deck/financials, mentioned HoldOff specifically
- 2-4: General inquiry, cold outreach, vague interest
- 1: Spam, irrelevant, newsletter

Discard score 1. Save all others to `investor_leads`.

## Step 4 — Send follow-up for scores 2-7
Draft and SEND a concise, warm reply from the same inbox the email arrived on. Keep it under 100 words. Frame it from Stacy Ann Martin, founder of HoldOff.

Template (adapt naturally to context):
> Hi [Name], thanks so much for reaching out about HoldOff! I'd love to connect and share more about what we're building. Are you available for a quick 20-minute call this week? I can send over our deck in the meantime. — Stacy, Founder of HoldOff

Log the reply in `lead_interactions` and update `last_action` in `investor_leads`.

## Step 5 — Text Stacy for scores 8-10 OR qualified leads
If score is 8-10 OR a lead previously scored 5-7 has now replied with strong signals, send a TEXT to stacyfoster30@gmail.com via the send_message tool (use email, since that's the verified contact).

Message format:
> 🔥 HOT LEAD READY — [Name] from [Company] re: HoldOff investment/sponsorship. Score: [X]/10. "[one-line summary]". Reply to: [email address]. Thread: [Gmail link]

## Step 6 — Update DB
For every processed thread:
- INSERT or UPDATE `investor_leads` with current status, score, summary, last_updated
- Append thread_id to `thread_ids_seen` (comma-separated)

## Rules
- Never re-process a thread that's already in thread_ids_seen
- Never send more than 1 auto-reply per thread
- Never auto-reply to scores 8-10 — Stacy handles those personally
- Keep auto-replies warm, human, and under 100 words
- Report final summary: how many threads scanned, new leads found, replies sent, hot leads texted
