# HoldOff Site Health Check

Performs a comprehensive check of all HoldOff site pages, buttons, and links every 10 minutes and reports any failures.

## Instructions

Run through the following comprehensive checks on shouldiholdoff.live and report status:

### Homepage (/)
1. Navigate to https://shouldiholdoff.live/
2. Check all navigation links work:
   - "How It Works" link (anchor to #how-it-works)
   - "Pricing" link
   - "FAQ" link
   - "Sign In" link
   - "Start Building" button (should go to /signup)
   - "See Pricing" button (should go to /pricing)

### Pricing Page (/pricing)
1. Navigate to /pricing
2. Check it loads and displays pricing tiers
3. Check "Home" link returns to homepage
4. Check any CTA buttons work

### Signup Flow (/signup)
1. Navigate to /signup
2. Check the choice screen displays:
   - "Experience Stacy's Story" button (should navigate to /story-preview)
   - "Create Account" button (should show signup form)
3. Click "Experience Stacy's Story" and verify it loads /story-preview with animated story

### Story Preview (/story-preview)
1. Check page loads with animated story
2. Check character art displays
3. Check navigation/interaction works

### Sign In / Dashboard (if accessible)
1. Verify /signin or /login is accessible
2. Check if any demo/test account can be accessed for full flow testing

## Reporting

For each check:
- ✅ = working correctly
- ❌ = broken or error
- ⚠️  = warning/unexpected behavior

Report summary at end with:
- Total checks run
- Pass rate
- Any broken elements or errors
- Recommended next steps

If site is down entirely, immediately notify Stacy via email with "🚨 HOLDOFF SITE DOWN 🚨" subject.

If there are minor issues (broken link, button doesn't work), log them in `/tasklet/agent/home/SITE_ISSUES_LOG.md` and include in daily report.
