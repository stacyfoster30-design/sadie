# Connections Configuration

This document describes the connections needed for the agent to function autonomously. Each connection must be created through the Tasklet UI (Connections capability).

---

## 1. Gmail: stacyfoster30@gmail.com (Personal)

**Purpose:** Payment/billing verification, subscription audits, investment lead reception, personal correspondence

**Scope:**
- Read/write access to inbox
- Ability to search threads (by sender, subject, date)
- Send emails from this account
- Mark as read/unread, archive, trash

**How to create:**
1. Go to Connections → New Connection
2. Select "Gmail"
3. Sign in as stacyfoster30@gmail.com
4. Grant scopes: `gmail.modify`, `gmail.send`
5. Name: "stacyfoster30 Gmail"
6. Save and note the connection ID (e.g., `conn_3v0s3wxfctqc8313myxx`)

**Used by:**
- Investor lead qualifier (scans for investment/sponsorship emails)
- Health check (receives uptime alerts)
- Cold email sender (receives replies to check engagement)
- Revenue tracking (verifies subscription confirmations)

**In subagent code, reference as:** `conn_ID` variable, e.g., `conn_3v0s3wxfctqc8313myxx`

---

## 2. Gmail: holdoff.3minpause@gmail.com (Business)

**Purpose:** HoldOff partnership outreach, social media business account liaison, official pitches

**Scope:**
- Read/write access to inbox
- Search threads
- Send emails
- Archive/trash

**How to create:**
1. Go to Connections → New Connection
2. Select "Gmail"
3. Sign in as holdoff.3minpause@gmail.com
4. Grant scopes: `gmail.modify`, `gmail.send`
5. Name: "HoldOff Business Gmail"
6. Save and note the connection ID (e.g., `conn_3wfds9my5dtch57e74dk`)

**Used by:**
- Investor lead qualifier (sends auto-replies to warm leads)
- Social media posting (may receive DM forwarding from socials)
- Partnership outreach (cold_email_sender sends pitches from this account)

**In subagent code, reference as:** connection ID for queries and send operations

---

## 3. GitHub (stacyforten30-design organization)

**Purpose:** Push commits, create branches, trigger Actions, edit files (web UI), manage Holdoff + PocketPR repos

**Scope:**
- Write access to `stacyforten30-design/Holdoff` (private repo)
- Write access to `stacyforten30-design/PocketPR` (private repo)
- Ability to trigger workflows (Actions)

**How to create:**
1. Go to Connections → New Connection
2. Select "GitHub" or "Custom MCP" (if direct GitHub tool not available)
3. Authenticate as stacyfoster30@gmail.com (owner of the organization)
4. Grant repo permissions: `admin` or `write` on specified repos
5. Name: "GitHub stacyforten30-design"
6. Save and note the connection ID

**Important Notes:**
- GitHub **API push is currently blocked** (returns 403 on private repos)
- All file edits must go through **GitHub web UI** (browser capability)
- But: webhook triggers and Actions workflows work fine via API
- Workflow file edits themselves still require browser UI (GH blocks them via API)

**Used by:**
- github_file_pusher (commits via browser, not API)
- CI/CD triggers (watches for push events on main branch)
- APK build monitoring (reads Actions run results)

**In subagent code, reference as:** connection ID for Actions-related queries only; file uploads use browser

---

## 4. Browser Capability (Built-In)

**Purpose:** Web automation for Namecheap DNS, GitHub web edits, Play Store uploads, TikTok/Twitter/Instagram posting

**No separate connection needed.** This is a built-in Tasklet capability.

**Used for:**
- DNS management (Namecheap domain control panel)
- GitHub file edits (edit this file / commit via web)
- Play Console uploads (APK/AAB signing and release)
- Social media posting (TikTok, Twitter, Instagram, LinkedIn)
- Third-party logins (e.g., Stripe, Firebase console)

**Requirements:**
- Must be able to take screenshots/accessibility snapshots
- Can navigate, click, fill forms, type
- Can handle OAuth redirects
- Can upload files

**In subagent code, use:** `browser` tool with `navigate`, `click`, `fill_form`, `wait_for`, `snapshot` actions

---

## 5. Contacting Users Capability (Built-In)

**Purpose:** Send urgent SMS/email messages to Stacy (verified contact methods only)

**No separate connection needed.** Contact methods are managed via Contacting Users capability.

**Verify these contact methods exist:**
1. Go to Contacting Users capability
2. Check for verified methods:
   - stacyfoster30@gmail.com (email)
   - Stacy's phone number (for SMS, if added)

**If missing, add them:**
1. Click "Add Contact Method"
2. Enter email or phone
3. Verify code sent to that address/number
4. Confirm verified

**Used for:**
- Investor lead escalation (texts hot leads to Stacy)
- Critical alerts (site down, payment failure)
- Daily/weekly summary reports

**In subagent code, use:** `send_message` tool with `email` or `sms` format to Stacy's verified address/phone

---

## 6. Agent Database (Built-In)

**Purpose:** Persistent storage for investor leads, revenue tracking, social posts, interactions

**No connection needed.** This is per-agent SQL database.

**Tables to create** (see database_schema.md):
- `investor_leads` (scores, statuses, contact history)
- `lead_interactions` (inbound/outbound email log)
- `revenue_tracking` (MRR, user counts, conversion rates)
- `social_posts` (post URLs, engagement, scheduling)

**In subagent code, query with:** Agent DB capability (read/write SQL)

---

## 7. Task Management Capability (Built-In)

**Purpose:** Optional — track backlog items, blockers, and multi-step workflows

**Used by:** agent itself for tracking work state and priority

**Not required for subagents.** Can be used for logging and status updates.

---

## Connection Status Checklist

Create these in order. Test each one before moving to the next:

- [ ] Gmail: stacyfoster30@gmail.com (test: search for "invest" in inbox)
- [ ] Gmail: holdoff.3minpause@gmail.com (test: send a draft email)
- [ ] GitHub stacyforten30-design (test: view Holdoff repo via browser)
- [ ] Browser capability (test: navigate to shouldiholdoff.live)
- [ ] Contacting Users (test: verify stacyfoster30@gmail.com is confirmed)
- [ ] Agent DB (test: run `SELECT 1;` — should return success)

Once all pass, move to Step 3 (Initialize Database) in SETUP.md.

---

## Credentials & Secrets

**Never store these in subagent code or commit them to repos.** Instead:

1. **Fly.io secrets** → use Fly.io dashboard to store API keys, OAuth tokens
2. **Local .env** → use `/tasklet/agent/home/.env` for development (never commit)
3. **Connection IDs** → safe to reference in code (e.g., `conn_xxxxx`)

Example `.env` (add to .gitignore):
```
GROQ_API_KEY=gsk_l0iEUR...
ANTHROPIC_API_KEY=AQ.Ab8RN...
GOOGLE_CLIENT_ID=251734222269-...
```

Then in code:
```typescript
const groqKey = process.env.GROQ_API_KEY;
const connId = 'conn_3v0s3wxfctqc8313myxx';  // Safe to hardcode
```
