# Agent Database Schema

This document provides the SQL schema for initializing the agent's persistent database. Run these statements in the Agent DB capability to create all necessary tables.

---

## Table 1: investor_leads

Tracks all investment, sponsorship, and partnership opportunities, their scores, and conversation state.

```sql
CREATE TABLE IF NOT EXISTS investor_leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email_address TEXT NOT NULL UNIQUE,
  name TEXT,
  company TEXT,
  thread_id TEXT UNIQUE,
  inbox TEXT NOT NULL DEFAULT 'stacyfoster30@gmail.com',
  status TEXT NOT NULL DEFAULT 'new',
  score INTEGER NOT NULL DEFAULT 5,
  summary TEXT,
  last_action TEXT,
  last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
  thread_ids_seen TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_investor_leads_status ON investor_leads(status);
CREATE INDEX IF NOT EXISTS idx_investor_leads_score ON investor_leads(score);
CREATE INDEX IF NOT EXISTS idx_investor_leads_inbox ON investor_leads(inbox);
```

**Columns:**
- `id` — unique identifier
- `email_address` — sender email (unique; prevents duplicates)
- `name` — sender's name
- `company` — their company/organization
- `thread_id` — Gmail thread ID (unique; prevents re-processing same thread)
- `inbox` — which email account received it (stacyfoster30, stacymartin1008, holdoff.3minpause)
- `status` — `new`, `contacted`, `replied`, `qualified`, `passed`
- `score` — 1–10 based on email content/interest level
- `summary` — one-line summary of their ask/interest
- `last_action` — description of last action taken (e.g., "Sent warm reply")
- `last_updated` — timestamp of last DB update
- `thread_ids_seen` — comma-separated list of all thread IDs from this contact (to avoid re-processing)
- `created_at` — when lead was first added

**Queries the subagent uses:**
```sql
-- Find new leads not yet contacted
SELECT * FROM investor_leads WHERE status = 'new' ORDER BY score DESC;

-- Check if thread already processed
SELECT id FROM investor_leads WHERE thread_ids_seen LIKE '%{threadId}%';

-- Find qualified leads ready for Stacy
SELECT * FROM investor_leads WHERE status = 'qualified' AND score >= 8;

-- Update after sending reply
UPDATE investor_leads SET status = 'contacted', last_action = '...', last_updated = NOW() WHERE id = ?;
```

---

## Table 2: lead_interactions

Log of every inbound and outbound email for each lead. Used to track conversation history and detect patterns.

```sql
CREATE TABLE IF NOT EXISTS lead_interactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL,
  direction TEXT NOT NULL,
  subject TEXT,
  body_snippet TEXT,
  from_email TEXT,
  to_email TEXT,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  thread_id TEXT,
  FOREIGN KEY (lead_id) REFERENCES investor_leads(id)
);

CREATE INDEX IF NOT EXISTS idx_lead_interactions_lead_id ON lead_interactions(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_interactions_direction ON lead_interactions(direction);
```

**Columns:**
- `id` — unique interaction record
- `lead_id` — foreign key to `investor_leads.id`
- `direction` — `inbound` or `outbound`
- `subject` — email subject
- `body_snippet` — first 500 chars of email body
- `from_email` — sender email address
- `to_email` — recipient email address
- `sent_at` — when the email was sent
- `thread_id` — Gmail thread ID (for deduplication)

**Queries:**
```sql
-- Get all interactions for a lead
SELECT * FROM lead_interactions WHERE lead_id = ? ORDER BY sent_at DESC;

-- Count replies from a lead (engagement signal)
SELECT COUNT(*) as reply_count FROM lead_interactions 
WHERE lead_id = ? AND direction = 'inbound' AND sent_at > DATE('now', '-7 days');

-- Check if we already replied to this thread
SELECT id FROM lead_interactions WHERE thread_id = ? AND direction = 'outbound';
```

---

## Table 3: revenue_tracking

Daily snapshot of MRR, user counts, conversion rates, and churn. Updated daily by health check.

```sql
CREATE TABLE IF NOT EXISTS revenue_tracking (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date DATE NOT NULL UNIQUE,
  total_users INTEGER DEFAULT 0,
  paying_users INTEGER DEFAULT 0,
  free_users INTEGER DEFAULT 0,
  mrr REAL DEFAULT 0.0,
  arr REAL DEFAULT 0.0,
  churn_rate REAL DEFAULT 0.0,
  new_signups INTEGER DEFAULT 0,
  new_paid INTEGER DEFAULT 0,
  avg_subscription_months REAL DEFAULT 0.0,
  top_plan TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_revenue_tracking_date ON revenue_tracking(date);
```

**Columns:**
- `id` — unique record
- `date` — snapshot date (YYYY-MM-DD)
- `total_users` — total accounts created
- `paying_users` — active paid subscriptions
- `free_users` — free trial or non-paying users
- `mrr` — monthly recurring revenue (all paying users × plan price)
- `arr` — annual recurring revenue (MRR × 12)
- `churn_rate` — % of paying users who canceled this month
- `new_signups` — new accounts created today
- `new_paid` — new paying subscribers today
- `avg_subscription_months` — average time a paying user stays subscribed
- `top_plan` — most popular plan (e.g., "Companion $9.99/mo")
- `notes` — any special events (promo, outage, press, etc.)
- `created_at` — when this snapshot was taken

**Queries:**
```sql
-- Get today's revenue metrics
SELECT * FROM revenue_tracking WHERE date = DATE('now');

-- Get 30-day revenue trend
SELECT date, mrr, paying_users FROM revenue_tracking 
WHERE date >= DATE('now', '-30 days') ORDER BY date;

-- Find growth anomalies
SELECT date, new_paid, mrr FROM revenue_tracking 
WHERE date >= DATE('now', '-7 days') ORDER BY date DESC;

-- Update today's metrics
INSERT OR REPLACE INTO revenue_tracking 
(date, total_users, paying_users, mrr, new_paid, notes) 
VALUES (DATE('now'), ?, ?, ?, ?, ?);
```

---

## Table 4: social_posts

History of all social media posts (TikTok, Twitter, Instagram, LinkedIn). Used for engagement tracking and rotation state.

```sql
CREATE TABLE IF NOT EXISTS social_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT NOT NULL,
  post_type TEXT,
  content_snippet TEXT,
  post_url TEXT UNIQUE,
  posted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  engagement_rate REAL DEFAULT 0.0,
  script_index INTEGER,
  thread_index INTEGER,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_social_posts_platform ON social_posts(platform);
CREATE INDEX IF NOT EXISTS idx_social_posts_posted_at ON social_posts(posted_at);
```

**Columns:**
- `id` — unique post record
- `platform` — `tiktok`, `twitter`, `instagram`, `linkedin`
- `post_type` — `video`, `thread`, `carousel`, `text`
- `content_snippet` — first 200 chars of post text/caption
- `post_url` — direct link to post on platform
- `posted_at` — when posted
- `views` — engagement metric (if available)
- `likes` — engagement metric
- `shares` — engagement metric
- `comments` — engagement metric
- `engagement_rate` — (likes + comments + shares) / views
- `script_index` — which TikTok script was used (0–4)
- `thread_index` — which Twitter thread was used (0–3)
- `notes` — any special notes (e.g., "went viral", "low engagement")
- `created_at` — when record was created

**Queries:**
```sql
-- Get posts from last 24 hours
SELECT platform, engagement_rate FROM social_posts 
WHERE posted_at > DATETIME('now', '-1 day') 
ORDER BY platform, posted_at DESC;

-- Find best-performing content
SELECT platform, content_snippet, engagement_rate FROM social_posts 
WHERE posted_at > DATETIME('now', '-30 days') 
ORDER BY engagement_rate DESC LIMIT 5;

-- Log a new post
INSERT INTO social_posts 
(platform, post_url, posted_at, content_snippet, script_index) 
VALUES (?, ?, NOW(), ?, ?);

-- Update engagement metrics
UPDATE social_posts SET views = ?, likes = ?, engagement_rate = ? 
WHERE id = ?;
```

---

## Table 5: grant_applications

Track grant applications submitted, deadlines, and outcomes.

```sql
CREATE TABLE IF NOT EXISTS grant_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  grant_name TEXT NOT NULL,
  organization TEXT,
  deadline DATE,
  status TEXT NOT NULL DEFAULT 'applied',
  amount_requested REAL,
  amount_awarded REAL DEFAULT 0.0,
  application_url TEXT,
  confirmation_number TEXT,
  applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  result_date DATE,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_grant_applications_status ON grant_applications(status);
CREATE INDEX IF NOT EXISTS idx_grant_applications_deadline ON grant_applications(deadline);
```

**Columns:**
- `id` — unique application record
- `grant_name` — name of grant/program
- `organization` — issuing organization
- `deadline` — application deadline
- `status` — `applied`, `pending`, `accepted`, `rejected`, `withdrawn`
- `amount_requested` — how much we asked for
- `amount_awarded` — how much we actually got (if accepted)
- `application_url` — link to grant page
- `confirmation_number` — confirmation or reference number from submission
- `applied_at` — when we submitted
- `result_date` — when results were announced
- `notes` — any special notes (e.g., "requires Q3 reapplication")
- `created_at` — when record was created

**Queries:**
```sql
-- Find upcoming deadlines
SELECT grant_name, deadline, amount_requested FROM grant_applications 
WHERE status IN ('applied', 'pending') 
AND deadline > DATE('now') 
AND deadline < DATE('now', '+30 days') 
ORDER BY deadline;

-- Sum total awarded
SELECT SUM(amount_awarded) as total_awarded FROM grant_applications 
WHERE status = 'accepted';

-- Get acceptance rate
SELECT 
  SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) as accepted,
  COUNT(*) as total,
  ROUND(100.0 * SUM(CASE WHEN status = 'accepted' THEN 1 ELSE 0 END) / COUNT(*), 2) as acceptance_rate
FROM grant_applications;
```

---

## Table 6: ai_heuristic_log

Track AI verdict decisions for debugging and improvement. Optional but recommended.

```sql
CREATE TABLE IF NOT EXISTS ai_heuristic_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  input_text TEXT,
  ai_model TEXT,
  verdict TEXT,
  confidence REAL DEFAULT 0.0,
  reasoning TEXT,
  processing_time_ms INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_ai_heuristic_log_user_id ON ai_heuristic_log(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_heuristic_log_created_at ON ai_heuristic_log(created_at);
```

**Columns:**
- `id` — unique log entry
- `user_id` — which user submitted the text
- `input_text` — the text the user entered
- `ai_model` — which model made the decision (Groq, Anthropic, etc.)
- `verdict` — the AI's output/recommendation
- `confidence` — 0.0–1.0 confidence score from the model
- `reasoning` — brief explanation of why the AI chose that verdict
- `processing_time_ms` — how long the AI took to decide (for performance monitoring)
- `created_at` — timestamp

**Queries:**
```sql
-- Debug low-confidence verdicts
SELECT input_text, verdict, confidence FROM ai_heuristic_log 
WHERE confidence < 0.5 
ORDER BY created_at DESC LIMIT 10;

-- Monitor average processing time
SELECT 
  ai_model,
  ROUND(AVG(processing_time_ms), 2) as avg_time_ms,
  MAX(processing_time_ms) as max_time_ms
FROM ai_heuristic_log 
WHERE created_at > DATETIME('now', '-7 days')
GROUP BY ai_model;
```

---

## Initialization Script

To create all tables at once, run this complete SQL:

```sql
-- Create all tables
CREATE TABLE IF NOT EXISTS investor_leads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email_address TEXT NOT NULL UNIQUE,
  name TEXT,
  company TEXT,
  thread_id TEXT UNIQUE,
  inbox TEXT NOT NULL DEFAULT 'stacyfoster30@gmail.com',
  status TEXT NOT NULL DEFAULT 'new',
  score INTEGER NOT NULL DEFAULT 5,
  summary TEXT,
  last_action TEXT,
  last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
  thread_ids_seen TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS lead_interactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lead_id INTEGER NOT NULL,
  direction TEXT NOT NULL,
  subject TEXT,
  body_snippet TEXT,
  from_email TEXT,
  to_email TEXT,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  thread_id TEXT,
  FOREIGN KEY (lead_id) REFERENCES investor_leads(id)
);

CREATE TABLE IF NOT EXISTS revenue_tracking (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  date DATE NOT NULL UNIQUE,
  total_users INTEGER DEFAULT 0,
  paying_users INTEGER DEFAULT 0,
  free_users INTEGER DEFAULT 0,
  mrr REAL DEFAULT 0.0,
  arr REAL DEFAULT 0.0,
  churn_rate REAL DEFAULT 0.0,
  new_signups INTEGER DEFAULT 0,
  new_paid INTEGER DEFAULT 0,
  avg_subscription_months REAL DEFAULT 0.0,
  top_plan TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS social_posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  platform TEXT NOT NULL,
  post_type TEXT,
  content_snippet TEXT,
  post_url TEXT UNIQUE,
  posted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  shares INTEGER DEFAULT 0,
  comments INTEGER DEFAULT 0,
  engagement_rate REAL DEFAULT 0.0,
  script_index INTEGER,
  thread_index INTEGER,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS grant_applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  grant_name TEXT NOT NULL,
  organization TEXT,
  deadline DATE,
  status TEXT NOT NULL DEFAULT 'applied',
  amount_requested REAL,
  amount_awarded REAL DEFAULT 0.0,
  application_url TEXT,
  confirmation_number TEXT,
  applied_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  result_date DATE,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ai_heuristic_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  input_text TEXT,
  ai_model TEXT,
  verdict TEXT,
  confidence REAL DEFAULT 0.0,
  reasoning TEXT,
  processing_time_ms INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Create indices for performance
CREATE INDEX IF NOT EXISTS idx_investor_leads_status ON investor_leads(status);
CREATE INDEX IF NOT EXISTS idx_investor_leads_score ON investor_leads(score);
CREATE INDEX IF NOT EXISTS idx_investor_leads_inbox ON investor_leads(inbox);
CREATE INDEX IF NOT EXISTS idx_lead_interactions_lead_id ON lead_interactions(lead_id);
CREATE INDEX IF NOT EXISTS idx_lead_interactions_direction ON lead_interactions(direction);
CREATE INDEX IF NOT EXISTS idx_revenue_tracking_date ON revenue_tracking(date);
CREATE INDEX IF NOT EXISTS idx_social_posts_platform ON social_posts(platform);
CREATE INDEX IF NOT EXISTS idx_social_posts_posted_at ON social_posts(posted_at);
CREATE INDEX IF NOT EXISTS idx_grant_applications_status ON grant_applications(status);
CREATE INDEX IF NOT EXISTS idx_grant_applications_deadline ON grant_applications(deadline);
CREATE INDEX IF NOT EXISTS idx_ai_heuristic_log_user_id ON ai_heuristic_log(user_id);
CREATE INDEX IF NOT EXISTS idx_ai_heuristic_log_created_at ON ai_heuristic_log(created_at);
```

---

## Backup & Maintenance

- **Regular backups:** Schedule a database backup weekly (via Tasklet's built-in backup or manual export)
- **Cleanup:** Delete records older than 6 months from `social_posts` and `ai_heuristic_log` to save space
- **Monitoring:** Query table sizes periodically to catch runaway growth:
  ```sql
  -- Get row counts
  SELECT 'investor_leads' as table_name, COUNT(*) as row_count FROM investor_leads
  UNION ALL
  SELECT 'lead_interactions', COUNT(*) FROM lead_interactions
  UNION ALL
  SELECT 'revenue_tracking', COUNT(*) FROM revenue_tracking
  UNION ALL
  SELECT 'social_posts', COUNT(*) FROM social_posts;
  ```

---

## Testing the Schema

After creating all tables, verify they exist:

```sql
-- List all tables
SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;

-- Should return:
-- ai_heuristic_log
-- grant_applications
-- lead_interactions
-- investor_leads
-- revenue_tracking
-- social_posts
```

If any table is missing, re-run the CREATE TABLE statement for it.

Now you're ready for Step 5 (Deploy Subagents) in SETUP.md!
