# Triggers Configuration

This document describes the scheduled and event-based triggers that automate the agent's core workflows. All triggers are created via the Trigger Management capability.

---

## Trigger 1: Investor Lead Sweep (Every 4 Hours)

**Purpose:** Autonomously scan all 3 email inboxes for investment/sponsorship opportunities, qualify leads, and escalate hot ones

**Subagent:** `investor_lead_qualifier`

**Schedule:** Every 4 hours (6 times daily)
- Recommended times: 12am, 4am, 8am, 12pm, 4pm, 8pm MT (or any 4-hour intervals)

**Trigger type:** Cron-based

**Cron expression:** `0 0,4,8,12,16,20 * * *` (UTC; adjust for your timezone)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron: `0 0,4,8,12,16,20 * * *`
4. Action: Run subagent → `investor_lead_qualifier`
5. Subagent inputs: (none required; it uses hardcoded connection IDs)
6. On completion: Subagent will text Stacy if hot leads (8+/10) are found
7. Save

**What it does:**
- Scans stacyfoster30@gmail.com, stacymartin1008@gmail.com, holdoff.3minpause@gmail.com
- Searches for: "invest", "funding", "capital", "equity", "sponsor", "partnership", "pitch", "brand deal", "term sheet"
- Scores each thread 1-10 based on email content
- Auto-replies to warm leads (scores 2-7) with brief interest response
- Texts Stacy for hot leads (8+/10)
- Updates `investor_leads` database with status and history
- Reports: threads scanned, new leads found, replies sent, hot escalations

**Success criteria:**
- Runs at scheduled time without errors
- Database `investor_leads` table updates after each run
- Stacy receives text on hot leads (score 8+)

---

## Trigger 2: Social Media Posting (4x Daily)

**Purpose:** Post HoldOff content to TikTok, Twitter, Instagram, LinkedIn on a fixed schedule

**Subagent:** `holdoff_social_poster`

**Schedule:** 4 times daily at:
- 9am MT
- 12pm MT
- 3pm MT
- 6pm MT

**Trigger type:** Cron-based (4 separate triggers, one for each time)

**Cron expressions:**
- 9am: `0 15 * * *` (15:00 UTC = 9am MT)
- 12pm: `0 18 * * *` (18:00 UTC = 12pm MT)
- 3pm: `0 21 * * *` (21:00 UTC = 3pm MT)
- 6pm: `0 0 * * *` (00:00 UTC next day = 6pm MT)

**Configuration (repeat for each time):**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron expression for the time slot
4. Action: Run subagent → `holdoff_social_poster`
5. Subagent inputs: none
6. Save and repeat for all 4 times

**What it does:**
- Reads `social_post_rotation.json` to determine which script/thread to post
- Pulls content from:
  - `holdoff_tiktok_launch_scripts.md` (5 rotating scripts)
  - `x_twitter_midnight_launch.md` (4 rotating threads)
  - `HOLDOFF_SOCIAL_MEDIA_CALENDAR.md` (fallback)
- Uses browser automation to:
  - Log into TikTok (@holdoffapp)
  - Log into Twitter/X (@holdoffapp)
  - Log into Instagram (@holdoffapp)
  - Log into LinkedIn (if enabled)
- Posts the content with hashtags and links
- Updates rotation index in `social_post_rotation.json`
- Logs post URLs for engagement tracking

**Success criteria:**
- 4 posts appear on each platform daily
- Posts go out at exact scheduled times (within 2 minutes)
- Rotation cycles through all content without repeating same post same day
- No login credential leaks in logs

**Notes:**
- Currently **disabled** by Stacy; re-enable when ready via trigger UI
- Requires valid TikTok, Twitter, Instagram, LinkedIn accounts and login credentials
- Browser automation may need monitoring if social platform UIs change

---

## Trigger 3: Health Check (Every 6 Hours)

**Purpose:** Monitor HoldOff site uptime, Fly.io health, Stripe webhook status, database connectivity

**Subagent:** `holdoff_health_check`

**Schedule:** Every 6 hours
- Recommended times: 12am, 6am, 12pm, 6pm MT

**Trigger type:** Cron-based

**Cron expression:** `0 0,6,12,18 * * *` (UTC)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron: `0 0,6,12,18 * * *`
4. Action: Run subagent → `holdoff_health_check`
5. Save

**What it does:**
- HTTP GET shouldiholdoff.live (checks frontend is serving)
- HTTP GET https://holdoff.fly.dev/api/health (checks backend is alive)
- Verifies Stripe webhook endpoint is registered and working
- Checks database connectivity and query response time
- Monitors recent crash logs in Fly.io
- Reports metrics:
  - Uptime % (success/total requests over 24h)
  - Response times (frontend, backend, database)
  - Last error (if any)
  - Stripe webhook status
- If any check fails: texts Stacy with error details

**Success criteria:**
- Runs without errors
- Stacy receives alert if site goes down
- Logs available in subagent run history

---

## Trigger 4: Site Health Check (Every 5 Minutes)

**Purpose:** Lightweight HTTP ping to shouldiholdoff.live; alert on downtime

**Subagent:** `site_health_check`

**Schedule:** Every 5 minutes (288 checks/day)

**Trigger type:** Cron-based

**Cron expression:** `*/5 * * * *` (every 5 minutes, UTC)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron: `*/5 * * * *`
4. Action: Run subagent → `site_health_check`
5. Save

**What it does:**
- Simple HTTP GET to shouldiholdoff.live
- Checks status code (200 = healthy)
- If down (non-200): increments failure counter
- If 5+ consecutive failures: texts Stacy
- Once restored: texts "site back up"
- Logs uptime % to database

**Success criteria:**
- Runs every 5 minutes without lag
- Stacy alerted within 25 minutes of outage (5 consecutive fails × 5 min)
- Alert includes: error status, URL, time of first failure

---

## Trigger 5: Grant Research Cycle (Every 2 Weeks)

**Purpose:** Search for and apply to relevant grants for HoldOff (women entrepreneurs, mental health, tech startups)

**Subagent:** `grant_researcher`

**Schedule:** Every 2 weeks starting June 26, 2026

**Trigger type:** Cron-based

**Cron expression:** `0 10 * * 4` repeated bi-weekly, OR use one-time + 14-day interval

**Easier method:** Create one scheduled trigger with interval setting:
- Frequency: Every 2 weeks
- Start date: June 26, 2026
- Start time: 10:00 AM MT

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled"
3. Set: Every 2 weeks, starting June 26, 2026 at 10am MT
4. Action: Run subagent → `grant_researcher`
5. Save

**What it does:**
- Searches for women entrepreneur grants, mental health nonprofits, mental health tech accelerators
- Checks: FastGrants, AmberGrants, WomensNet, incubators, corporate giving programs
- For each promising grant:
  - Reads application requirements
  - Fills out form auto with: Stacy's info, HoldOff story, revenue metrics, mission statement
  - Submits application
  - Logs deadline, grant name, status, confirmation number
- Reports: grants found, applications submitted, next deadlines

**Success criteria:**
- Runs every 2 weeks on schedule
- Applications submitted within 24 hours of run
- Confirmation emails captured and logged

---

## Trigger 6: Investor Outreach (3x Weekly)

**Purpose:** Send personalized investment pitch emails to targeted angels, VCs, and corporate partners

**Subagent:** `cold_email_sender`

**Schedule:** 3x weekly (Mon/Wed/Fri) at 10am MT

**Trigger type:** Cron-based

**Cron expression:** `0 16 * * 1,3,5` (10am MT = 16:00 UTC; Mon=1, Wed=3, Fri=5)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron: `0 16 * * 1,3,5`
4. Action: Run subagent → `cold_email_sender`
5. Save

**What it does:**
- Reads recipient list (targets must be pre-defined, e.g., CSV or database)
- For each recipient:
  - Pulls HoldOff founder story, prospectus, key metrics
  - Drafts 3-paragraph personalized pitch email
  - References recipient company/focus area if known
  - Sends from holdoff.3minpause@gmail.com
  - Logs: recipient email, sent at, reply status
- Reports: recipients emailed, opens (via tracking pixel if available), replies

**Success criteria:**
- 5–10 emails sent per run (adjust based on recipient list size)
- Emails personalized (not generic template)
- All emails logged in database
- Stacy can track opens/replies

**Prerequisites:**
- Recipient list populated (e.g., angels list, VC firms list)
- Email tracking enabled (optional but recommended)

---

## Trigger 7: GitHub File Pusher (On Demand)

**Purpose:** Commit and push modified files to Holdoff repo on command

**Subagent:** `github_file_pusher`

**Trigger type:** Manual (run on demand, NOT scheduled)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Manual Trigger" (one-time execution)
3. Action: Run subagent → `github_file_pusher`
4. Inputs:
   - file_path: (required) e.g., `views/story-animated.ejs`
   - commit_message: (required) e.g., "Update founder story with attachment-first narrative"
   - branch: (optional) defaults to `main`
5. Save

**What it does:**
- Reads file from `/tasklet/agent/home/{file_path}`
- Navigates to GitHub repo in browser
- Finds the file
- Clicks "Edit this file"
- Replaces content
- Commits with provided message
- Pushes to specified branch
- Logs commit SHA and URL
- Reports: file committed, branch, link to commit

**Usage:**
- Instead of manually uploading files to GitHub, invoke this trigger with file path + message
- Especially useful for: story updates, HTML template changes, configuration files

**Success criteria:**
- Commit appears on GitHub within 2 minutes
- Commit message matches input
- Correct file updated (not wrong branch)

---

## Trigger 8: Daily Status Report (Every Morning)

**Purpose:** Send Stacy a daily summary of HoldOff metrics, alerts, and top next actions

**Subagent:** Internal agent routine (not a separate subagent; agent itself sends message)

**Schedule:** Every morning at 8am MT

**Trigger type:** Cron-based

**Cron expression:** `0 14 * * *` (8am MT = 14:00 UTC)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron: `0 14 * * *`
4. Action: **Agent sends message** (use Contacting Users capability)
5. Message template:
   ```
   📊 **HoldOff Daily Status** — {date}
   
   **Metrics:**
   - Users: {total} (paying: {paid_count}, MRR: ${mrr})
   - Site Uptime: {uptime}%
   - Fly.io Health: {status}
   - Stripe Webhooks: {status}
   
   **Events:**
   - New leads found: {count}
   - Investor replies: {count}
   - Social posts: 4/4 scheduled
   - Grants applied: {count}
   
   **Alerts:**
   {any_errors_or_warnings}
   
   **Top Next Actions:**
   1. {action}
   2. {action}
   3. {action}
   ```
6. Save

**Success criteria:**
- Stacy receives email every morning at 8am MT
- Metrics are current (from database/API queries)
- Action items are concrete, not vague

---

## Trigger 9: Weekly Deep Dive (Every Sunday Evening)

**Purpose:** Comprehensive analysis and strategic recommendations for the week ahead

**Subagent:** Internal agent routine

**Schedule:** Every Sunday at 6pm MT

**Trigger type:** Cron-based

**Cron expression:** `0 0 * * 1` (6pm MT Sunday = midnight UTC Monday)

**Configuration:**
1. Go to Triggers → New Trigger
2. Select "Scheduled (Cron)"
3. Enter cron: `0 0 * * 1`
4. Action: Agent sends message with:
   - Full revenue analysis (MRR trend, churn, LTV)
   - Investor pipeline summary (qualified leads, replies, hot prospects)
   - Top 5 product improvements needed
   - Top 3 revenue opportunities
   - 5 concrete recommendations for the week
5. Save

**Success criteria:**
- Email sent every Sunday at 6pm
- Analysis is data-driven (pulls from database)
- Recommendations are actionable (not generic advice)

---

## Scheduling Checklist

Create these triggers in order:

- [ ] Investor Lead Sweep (every 4 hours)
- [ ] Social Media Posting (4x daily at 9am, 12pm, 3pm, 6pm)
  - [ ] 9am trigger
  - [ ] 12pm trigger
  - [ ] 3pm trigger
  - [ ] 6pm trigger
- [ ] Health Check (every 6 hours)
- [ ] Site Health Check (every 5 minutes)
- [ ] Grant Research (every 2 weeks)
- [ ] Investor Outreach (Mon/Wed/Fri at 10am)
- [ ] GitHub File Pusher (manual, on-demand)
- [ ] Daily Status Report (8am daily)
- [ ] Weekly Deep Dive (Sunday 6pm)

Once all are created, test each one manually to confirm it runs without errors.

---

## Testing a Trigger

1. Go to Trigger Management
2. Find the trigger
3. Click "Test" or "Run Now"
4. Monitor the run in the subagent logs
5. Verify output (email sent, database updated, etc.)
6. If error, check:
   - Subagent is deployed and valid
   - Connections are active (not expired)
   - Database tables exist
   - Cron expression is correct for your timezone

---

## Disabling/Pausing Triggers

To temporarily pause a trigger (e.g., social posting during a crisis):
1. Go to Triggers
2. Find the trigger
3. Click "Disable" or "Pause"
4. Trigger will not run until re-enabled
5. Subagent code remains unchanged; just toggle the trigger on/off

To permanently delete a trigger:
1. Go to Triggers
2. Find the trigger
3. Click "Delete"
4. Confirm deletion (cannot undo)

---

## Timezone Note

All cron expressions above assume UTC. If your agent's server is in a different timezone:
- Confirm your timezone in Tasklet settings
- Adjust cron expressions accordingly
- Or use a cron converter tool to translate your desired local time to UTC

Example: 
- Desired: 10am MT (Mountain Time)
- MT is UTC-6 (standard) or UTC-7 (daylight)
- 10am MT = 16:00 UTC (standard) or 17:00 UTC (daylight)
- During daylight saving, adjust the cron to `0 17 * * *` instead of `0 16 * * *`

For simplicity, Tasklet UI may allow "local time" entry directly without needing UTC conversion.
