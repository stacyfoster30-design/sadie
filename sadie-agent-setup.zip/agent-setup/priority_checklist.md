# Agent Setup Checklist

Complete these tasks in order to fully configure your new Sadie agent.

---

## Phase 1: Core Setup (30 minutes)

- [ ] **Read SETUP.md** — Understand the full workflow
- [ ] **Apply Custom Instructions** — Copy AGENTS.md to workspace settings
- [ ] **Create Gmail connections**
  - [ ] stacyfoster30@gmail.com
  - [ ] holdoff.3minpause@gmail.com
- [ ] **Create GitHub connection** — stacyforten30-design organization
- [ ] **Verify Contact Methods** — Confirm stacyfoster30@gmail.com is verified in Contacting Users
- [ ] **Initialize Database** — Run all SQL from database_schema.md

---

## Phase 2: Subagent Deployment (15 minutes)

For each file in `subagents/`:

- [ ] investor_lead_qualifier
- [ ] holdoff_social_poster
- [ ] holdoff_health_check
- [ ] site_health_check
- [ ] grant_researcher (if available in original workspace)
- [ ] cold_email_sender (if available)
- [ ] github_file_pusher (if available)

For each:
1. Copy the `.md` content
2. Go to Subagents capability
3. Create new subagent with the same name
4. Paste instructions
5. Save
6. Test: Run manually via UI to confirm no errors

---

## Phase 3: Trigger Scheduling (20 minutes)

Follow `triggers_config.md`:

- [ ] Investor Lead Sweep (every 4 hours)
- [ ] Social Media Posting (4x daily)
  - [ ] 9am
  - [ ] 12pm
  - [ ] 3pm
  - [ ] 6pm
- [ ] Health Check (every 6 hours)
- [ ] Site Health Check (every 5 minutes)
- [ ] Grant Research (every 2 weeks)
- [ ] Investor Outreach (3x weekly)
- [ ] GitHub File Pusher (manual, on-demand)
- [ ] Daily Status Report (8am daily)
- [ ] Weekly Deep Dive (Sunday 6pm)

---

## Phase 4: Verify Setup (30 minutes)

### Test Each Connection
- [ ] Gmail: stacyfoster30@gmail.com — search for "invest", get 5+ results
- [ ] Gmail: holdoff.3minpause@gmail.com — send a test draft
- [ ] GitHub — navigate to Holdoff repo, confirm authenticated
- [ ] Browser — navigate to shouldiholdoff.live, take screenshot
- [ ] Contact Methods — verify stacyfoster30@gmail.com is confirmed

### Test Database
- [ ] Agent DB — run `SELECT COUNT(*) FROM investor_leads;` — should return 0 (empty but exists)
- [ ] All 6 tables exist: investor_leads, lead_interactions, revenue_tracking, social_posts, grant_applications, ai_heuristic_log

### Test Subagents
- [ ] investor_lead_qualifier — run manually, should return "0 threads scanned" (on first run)
- [ ] holdoff_health_check — run manually, should return site status
- [ ] site_health_check — run manually, should return ✅ or ❌ for site

### Test Triggers
- [ ] Pick one simple trigger (e.g., health check)
- [ ] Click "Run Now" / "Test"
- [ ] Monitor logs — should complete without errors
- [ ] Repeat for 2–3 more triggers

---

## Phase 5: Local Files (15 minutes)

Create or sync these files to `/tasklet/agent/home/`:

- [ ] **REVENUE_TRACKING_LIVE.md** — Template or copy from original workspace
- [ ] **HOLDOFF_INVESTOR_PROSPECTUS.md** + **.pdf** — Investor deck (44 sections)
- [ ] **social_post_rotation.json** — Initial rotation state:
  ```json
  {
    "lastUpdated": "2026-07-03T19:00:00Z",
    "promoActive": true,
    "tiktok": { "currentScriptIndex": 0 },
    "twitter": { "currentThreadIndex": 0 },
    "instagram": { "currentIndex": 0 },
    "linkedin": { "enabled": false }
  }
  ```
- [ ] **holdoff_tiktok_launch_scripts.md** — 5 TikTok scripts
- [ ] **x_twitter_midnight_launch.md** — 4 Twitter threads
- [ ] **HOLDOFF_SOCIAL_MEDIA_CALENDAR.md** — Master content calendar
- [ ] **.env** (local, not committed) — Any secrets needed for development

---

## Phase 6: Verify Autonomy (10 minutes)

**Check that the agent acts without asking:**

- [ ] Read custom instructions — confirm agent personality is "Sadie" (no "Are you sure?" questions)
- [ ] Review subagent code — confirm they use tool calling, not asking for permission
- [ ] Check trigger logic — confirm actions execute immediately, not waiting for approval

---

## Phase 7: Hands-Off Validation (5 minutes)

Let the agent run for 1 hour without intervention:

- [ ] Investor lead sweep completed (check logs)
- [ ] Health check ran and reported status
- [ ] No errors in subagent logs
- [ ] Stacy received expected messages/alerts (if configured)

---

## Done! ✅

Your agent is now configured and running autonomously.

**Next steps:**
1. Monitor the agent for 24 hours — ensure no persistent errors
2. Adjust trigger frequencies based on your preferences (e.g., slower/faster)
3. Customize subagent prompts if needed (e.g., add your own rules/preferences)
4. Add new subagents as you build them (e.g., newsletter sender, content curator)

---

## Troubleshooting

| Issue | Check |
|-------|-------|
| Subagent won't run | Is it deployed? Do connections exist? Run test manually. |
| Trigger not executing | Check cron expression. Test trigger manually. Verify subagent exists. |
| No database access | Run `SELECT 1;` in agent-db. If error, re-run schema creation. |
| Connections expired | Reauthenticate in Connections UI. Gmail/GitHub may need re-auth every 3-6 months. |
| Email not sending | Verify contact method is confirmed. Check send_message tool has email address. |

---

## Credits & History

This setup package was created from the configuration of **Sadie**, the autonomous HoldOff AI agent. It represents best practices for:
- Autonomous lead qualification
- Scheduled social media posting
- Revenue tracking and metrics
- Health/uptime monitoring
- Investor outreach and follow-up

Adapt this to your own business needs, but preserve the spirit: **act autonomously, default to helping the core mission, and report only when there are blockers or wins worth celebrating.**

Happy automating! 🚀
