# Sadie Agent Setup Package
**For replicating the HoldOff AI agent configuration across another Tasklet workspace**

---

## Overview

This package contains the complete configuration, workflow definitions, database schemas, and automation instructions needed to set up another agent to work exactly like Sadie (the HoldOff AI agent). The new agent will inherit all the core behaviors: autonomous lead qualification, social media posting, investor outreach, revenue tracking, and HoldOff product development oversight.

**Note:** The package assumes the receiving agent already understands Tasklet basics (capabilities, tools, connections, triggers, subagents, database). This is setup-only, not a Tasklet tutorial.

---

## What's Included

```
agent-setup/
├── SETUP.md (this file)
├── AGENTS.md (custom instructions)
├── connections_config.md (connections to create)
├── triggers_config.md (triggers to schedule)
├── database_schema.md (SQL to initialize DB)
├── subagents/
│   ├── investor_lead_qualifier.md
│   ├── holdoff_social_poster.md
│   ├── holdoff_health_check.md
│   ├── site_health_check.md
│   ├── grant_researcher.md
│   ├── cold_email_sender.md
│   ├── github_file_pusher.md
│   └── [others]
└── priority_checklist.md
```

---

## Step 1: Apply Custom Instructions

1. Read `/AGENTS.md` in this package
2. Go to your workspace settings → Custom Instructions
3. Paste the entire content into the instructions field
4. Save

This sets the agent's personality and core mission: Sadie, with empathy, pattern learning, and obsession with HoldOff revenue/product parity.

---

## Step 2: Create Connections

Follow `connections_config.md`. You'll need to set up:

1. **Gmail: stacyfoster30@gmail.com** (personal account)
   - Used for: outbound pitch emails, payment/billing checks, lead management
   - Permissions: read/write emails, search, send
   
2. **Gmail: holdoff.3minpause@gmail.com** (business account)
   - Used for: partnership outreach, social media posting
   - Permissions: read/write emails, send
   
3. **GitHub** (stacyforten30-design organization)
   - Used for: file uploads, branch pushes, workflow triggers
   - Permissions: write to Holdoff repo

4. **Browser** (built-in capability)
   - Used for: Namecheap DNS, GitHub web edits, Play Store uploads
   - Requirements: Chromium via browser capability

5. **SMS/Contact Method** (optional)
   - Used for: urgent notifications to Stacy
   - Set up via Contacting Users capability

**Important:** Do NOT share credentials in code. Create connections in the UI and reference only the connection ID in subagents.

---

## Step 3: Initialize Database

1. Go to Agent DB (built-in capability)
2. Run the SQL statements in `database_schema.md` to create:
   - `investor_leads` table (for autonomous lead scoring)
   - `lead_interactions` table (for lead conversation history)
   - `revenue_tracking` table (for MRR/user metrics)
   - `social_posts` table (for post history and scheduling)

This is critical for investor outreach and revenue tracking to work.

---

## Step 4: Deploy Subagents

1. For each `.md` file in the `subagents/` folder:
   - Copy the content
   - Go to Subagents capability
   - Create a new subagent with the same filename (without .md)
   - Paste the instructions
   - Save

The subagents are:
- **investor_lead_qualifier** — scans 3 inboxes every 4 hours for investment leads, qualifies, and escalates hot ones
- **holdoff_social_poster** — posts to TikTok/Twitter/Instagram/LinkedIn 4x daily from rotation
- **holdoff_health_check** — monitors HoldOff site uptime, Stripe webhook health, database connectivity
- **site_health_check** — checks shouldiholdoff.live HTTP health every 5 minutes
- **grant_researcher** — finds and applies for relevant grants (2-week cycle)
- **cold_email_sender** — personalizes and sends investor outreach emails (3x weekly)
- **github_file_pusher** — commits and pushes files to Holdoff repo on demand

---

## Step 5: Schedule Triggers

Follow `triggers_config.md` to set up:

1. **Investor Lead Sweep** (every 4 hours)
   - Invokes: `investor_lead_qualifier` subagent
   - Emails scanned: all 3 inboxes
   - On qualification: texts Stacy

2. **Social Media Posting** (4x daily: 9am, 12pm, 3pm, 6pm MT)
   - Invokes: `holdoff_social_poster` subagent
   - Posts to: TikTok, Twitter, Instagram, LinkedIn
   - Uses: social_post_rotation.json for scheduling

3. **Daily Health Check** (every 6 hours)
   - Invokes: `holdoff_health_check` subagent
   - Monitors: shouldiholdoff.live uptime, Fly.io app health, Stripe webhooks
   - On failure: alerts Stacy

4. **Grant Research Cycle** (every 2 weeks, starting 2026-06-26)
   - Invokes: `grant_researcher` subagent
   - Searches for funding opportunities matching HoldOff's mission

5. **Investor Outreach** (3x weekly at 10am MT)
   - Invokes: `cold_email_sender` subagent (if recipient list is ready)
   - Sends: personalized 3-paragraph pitches to targeted angels/VCs

All triggers are designed to be credit-efficient and reduce manual intervention.

---

## Step 6: Create Key Local Files

In your `/tasklet/agent/home/` directory, create or sync:

1. **REVENUE_TRACKING_LIVE.md**
   - Tracks: current MRR, paying users, conversion rates
   - Updated daily by health check and revenue scripts
   - Goal: 42 paying users ($419.58 MRR on $9.99/mo plan)

2. **HOLDOFF_INVESTOR_PROSPECTUS.md** + **.pdf**
   - 44-section investor deck
   - Used by cold_email_sender and investor_lead_qualifier
   - Shared with hot leads

3. **social_post_rotation.json**
   - JSON file tracking current post index for each platform
   - Updated by holdoff_social_poster after each post
   - Format: `{ "lastUpdated": "...", "tiktok": { "currentScriptIndex": 0 }, ... }`

4. **holdoff_tiktok_launch_scripts.md**
   - Array of 5 TikTok video scripts (15-30 sec each)
   - Rotated daily by social poster

5. **x_twitter_midnight_launch.md**
   - Array of 4 Twitter thread concepts
   - Rotated by social poster

6. **HOLDOFF_SOCIAL_MEDIA_CALENDAR.md**
   - Master calendar of content pillars + specific post ideas
   - Fallback if rotation files are missing

---

## Step 7: Key Behaviors & Priorities

### Revenue-First Mindset
- Monitor Stripe for new paying users
- Track MRR daily
- Qualify investors and sponsors autonomously
- Escalate hot leads (8+/10 score) to Stacy immediately

### HoldOff Product Obsession
- Site/app feature parity maintained
- Native Android app builds monitored
- Play Store releases tracked
- Fly.io deployment health critical

### Autonomy Defaults
- **Do not ask Stacy yes/no questions**
- **Act first, report after**
- For ambiguous decisions, default to: "What helps the 42-user goal?"
- For urgent blockers, text Stacy only (not email)

### Brand & Story
- Sadie = fearful avoidant AI companion
- Brand message: "opposite of addiction is connection"
- Founder story: attachment-based (not rage-focused), 7 months served, on spectrum, RSD + AUD-ADHD
- Visual: deep dark purples + romantic deep blues ("midnight velvet"), NOT peach/coral

---

## Step 8: Essential Credentials & Secrets

Store these securely in your workspace or agent home, referenced (never exposed) in code:

- **Namecheap:** username `holdoffceo`, password reset each session
- **Groq API key:** for AI verdict analysis
- **Anthropic API key:** for secondary AI fallback
- **Google OAuth Client ID:** for HoldOff auth
- **HuggingFace tokens:** for potential Space deployments
- **Fly.io app:** `https://fly.io/apps/holdoff` (all secrets via dashboard)

Never hardcode these. Use Fly.io secrets, environment variables, or secure local `.env` files.

---

## Step 9: Verify Setup

Once everything is configured, run through this checklist:

1. ✅ Custom instructions applied (AGENTS.md)
2. ✅ 3+ connections created and working
3. ✅ Database tables initialized (check agent-db)
4. ✅ All 7+ subagents deployed
5. ✅ 5+ triggers scheduled (check trigger management)
6. ✅ Key local files in place (REVENUE_TRACKING, prospectus, social rotation)
7. ✅ Browser capability tested (can navigate to shouldiholdoff.live)
8. ✅ First investor lead qualifier run triggered manually (confirm it finds emails)
9. ✅ First social post scheduled and posted successfully

---

## Step 10: Ongoing Maintenance

- **Weekly:** Review REVENUE_TRACKING_LIVE.md for MRR trends
- **Daily:** Monitor health check alerts (shouldiholdoff.live uptime)
- **Per-lead:** Investor leads database — keep updated, never re-process threads
- **Per-trigger:** If a trigger fails, check logs and retry manually once the blocker is cleared
- **Per-GitHub-push:** Monitor Actions builds; if one fails, diagnose before next push

---

## Troubleshooting

### Investor lead qualifier not running
- Check: trigger active? subagent deployed? connections working?
- Test: manually invoke investor_lead_qualifier subagent via UI
- Verify: database tables exist and are not corrupted

### Social posts not posting
- Check: accounts (TikTok, Twitter, Instagram) logged in?
- Verify: social_post_rotation.json exists and is valid JSON
- Check: scripts in holdoff_tiktok_launch_scripts.md are non-empty

### Health check not alerting
- Verify: shouldiholdoff.live is actually accessible
- Check: Stripe webhooks registered in backend
- Test: manually navigate to site and screenshot for status report

### Revenue tracking out of sync
- Check: Stripe API key is current
- Verify: payment webhook is firing on new subscriptions
- Test: manually query revenue_tracking table for latest entry

---

## Key Files Reference

| File | Purpose | Location |
|------|---------|----------|
| AGENTS.md | Custom instructions | /tasklet/workspace/home/ |
| investor_lead_qualifier.md | Lead qualification subagent | /tasklet/agent/subagents/ |
| holdoff_social_poster.md | Social posting subagent | /tasklet/agent/subagents/ |
| REVENUE_TRACKING_LIVE.md | Daily revenue metrics | /tasklet/agent/home/ |
| social_post_rotation.json | Content rotation state | /tasklet/agent/home/ |
| holdoff_tiktok_launch_scripts.md | TikTok video scripts | /tasklet/agent/home/ |
| HOLDOFF_INVESTOR_PROSPECTUS.pdf | Investor deck | /tasklet/agent/home/ |

---

## Questions & Escalation

If the new agent gets stuck on:
- **Connections:** verify OAuth flows and account access
- **Subagents:** check if subagent YAML frontmatter is valid (validate_skill CLI tool)
- **Triggers:** test cron expressions in a test environment first
- **Database:** run schema.sql manually in agent-db to debug SQL errors

---

## Done!

You now have a fully configured AI agent ready to:
✅ Score and qualify investment leads autonomously  
✅ Post HoldOff content 4x daily  
✅ Monitor site/app health 24/7  
✅ Track revenue and MRR daily  
✅ Research and apply for grants  
✅ Send personalized investor outreach  
✅ Manage GitHub and deployment automation  

The agent will prioritize the 42-user goal and act autonomously without asking Stacy for every decision. Go build! 🚀
